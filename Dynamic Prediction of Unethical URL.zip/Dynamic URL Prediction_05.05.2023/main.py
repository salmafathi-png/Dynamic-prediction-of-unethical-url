import pandas as pd
import warnings
import flask
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.preprocessing import LabelEncoder
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix
from sklearn.ensemble import RandomForestClassifier 
from sklearn.metrics import accuracy_score
from sklearn.naive_bayes import GaussianNB  
from sklearn import metrics

warnings.filterwarnings("ignore")

      # importing the dataset.
print("<----------Data Selection---------->")
print("************************************")
data=pd.read_csv('phishing1.csv')
print("Phishing Dataset")
print(data.head(10))
print()

print("<--------Data Preprocesing----------->")
print("************************************")

print(data.isnull().sum())
print()

print("<-------Label Encoding--------->")
print("********************************")

labelencoder=LabelEncoder()
data["type"]=LabelEncoder().fit_transform(data["type"])
print(data["type"].head())
print()
     # Splitting the data into features and target sets
print("<--------Model Selection------->" )
print("**********************************")

X=data['url']
print("X label Dataset")
print(X.head(10))
print()
Y=data["type"]
print("Y label Dataset")
print(Y.head(10))
print()

X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.20, random_state=2)
    
print("<---Data Splitting--->")
print("***********************")

print("Total no of data",len(data))
print("Total no of Training data",len(X_train))
print("Total no of Testing data",len(X_test))
print()

print("<----Count Vectorization----->")
print("*****************************")

     # create a CountVectorizer object
vectorizer=CountVectorizer()
X_train=vectorizer.fit_transform(X_train)
Xtest=vectorizer.transform(X_test)
print()

print("<----Algorithm---->")
print("*******************")
print()
print("<----Random Forest----->")
print("************************")

classifier= RandomForestClassifier(n_estimators= 10, criterion="entropy")  
classifier.fit(X_train, Y_train)  
y_pred= classifier.predict(Xtest)  
result2=accuracy_score(y_pred,Y_test)*100
print(result2)
print()

print("<---------Classification Report ---------->")
print("*******************************************")
print(metrics.classification_report(y_pred,Y_test))
print()


print("<----Naive bayes classifier----->")
print("*********************************")
X_train1=X_train.toarray()
Xtest1=Xtest.toarray()

classifier1 = GaussianNB()  
classifier1.fit(X_train1, Y_train)  
y_pred1= classifier1.predict(Xtest1)  
result1=accuracy_score(y_pred1,Y_test)*100
print(result1)
print()

print("<---------Classification Report ---------->")
print("*******************************************")
print(metrics.classification_report(y_pred1,Y_test))
print()

print("Confusion Matrix")
print("****************")
 #calculate the confusion matrix
cf_matrix = confusion_matrix(y_pred,Y_test)
print(cf_matrix)
print()
print('Confusion matrix\n\n')
sns.heatmap(cf_matrix, annot=True)
plt.title("Confusion Matrix")
plt.show()          
print()

print("<-------Comparision Graph------->")
print("********************************")
    #Comparision Graph b/w two algo
vals=[result1,result2]
inds=range(len(vals))
labels=["NB","RF"]
fig,ax = plt.subplots()
rects = ax.bar(inds, vals)
ax.set_xticks([ind for ind in inds])
ax.set_xticklabels(labels)
plt.title('Comparison graph')
plt.show()                
print()


import pickle
filename = 'website.pkl'
pickle.dump(classifier, open(filename, 'wb'))

import pickle
filename = 'vect.pkl'
pickle.dump(vectorizer, open(filename, 'wb'))

