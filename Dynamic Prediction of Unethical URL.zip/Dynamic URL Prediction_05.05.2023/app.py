
import numpy as np
from flask import Flask, request, jsonify, render_template, redirect, flash, send_file
import pickle
from flask import Flask, flash, request, redirect, url_for, render_template
UPLOAD_FOLDER = 'static/uploads/'

app = Flask(__name__) #Initialize the flask App
app.secret_key = "secret key"
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
# === LOAD MODEL =====

model = pickle.load(open('website.pkl','rb'))
vector = pickle.load(open('vect.pkl', 'rb'))


# === INDEX PAGE =====

@app.route('/')
@app.route('/')
@app.route('/index')

def index():
	return render_template('index.html')

# === LOGIN PAGE =====

@app.route('/login') 
def login():
	return render_template('home.html') 

@app.route("/predict", methods=['POST'])
def predict():
    if request.method == 'POST':

        
        Reviews = request.form['Reviews']
        #data = [Reviews]
        vect = vector.transform([Reviews])
        my_prediction = model.predict(vect)
        return render_template('result.html',prediction = my_prediction)
#    
   
if __name__ == "__main__":
    app.run(debug=True)
